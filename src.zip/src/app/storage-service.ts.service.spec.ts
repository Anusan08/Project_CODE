import { TestBed } from '@angular/core/testing';

import { StorageServiceTsService } from './storage-service.ts.service';

describe('StorageServiceTsService', () => {
  let service: StorageServiceTsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StorageServiceTsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
