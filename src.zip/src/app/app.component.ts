import { WriteKeyExpr } from '@angular/compiler';
import { Component, ViewChild } from '@angular/core';
import { window } from 'rxjs';
import { User } from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  @ViewChild('userForm') userForm: any;

  title = 'umt';
  btnText = "Add";

  userModel = new User(1,"Anu","mail")
  // userList = [
  //   { "id": 1, "name": "Thathin", "email": "raja@gmail.com" },
  //   { "id": 2, "name": "taj", "email": "taj@gmail.com" },
  //   { "id": 3, "name": "Deepika", "email": "Deepika@gmail.com" },
  // ];

  addUser() {
    
    
    if (this.btnText === "Add") {
     
      this.userList.push(this.userForm.value);
      this.userForm.reset();
    }

    else if (this.btnText === "Update") {
      const indexOfObject = this.userList.findIndex(object => {
        return object.id === this.userForm.value.id;
      });
      this.userList[indexOfObject] = this.userForm.value;
      this.userForm.reset();
      this.btnText = "Add";
    }

  }

  deleteUser(id: any) {
    const indexOfObject = this.userList.findIndex(object => {
      return object.id === id;
    });
    this.userList.splice(indexOfObject, 1);
    this.userForm.reset();
  }

  populateUserFormData(user: any) {
    console.log(user);
    this.btnText = "Update";

    this.userForm.setValue({
      id: user.id,
      name: user.name,
      email: user.email
    })
   
  }

  cancel() {
    this.userForm.reset();
  }

}
